﻿using Allsoft_assignment.Models;

namespace Allsoft_assignment.Repositories.Interfaces
{
    public interface IProductService
    {
        Task<List<Product>> GetProductsByCategoryAsync(int categoryId);
        Task<bool> AdjustPriceAsync(int productId, decimal percentage, decimal fixedAmount);
        Task<bool> AdjustPricesBulkAsync(List<int> productIds, decimal percentage, decimal fixedAmount);
        Task<bool> IsSkuUniqueAsync(string sku, int? productId = null);
        Task<Product> CreateProductAsync(Product product);
        Task<Product> UpdateProductAsync(int productId, Product product);
    }

}
