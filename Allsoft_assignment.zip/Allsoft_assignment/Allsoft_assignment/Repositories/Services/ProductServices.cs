﻿using Allsoft_assignment.Models;
using Allsoft_assignment.Repositories.Interfaces;

namespace Allsoft_assignment.Repositories.Services
{
    public class ProductServices : IProductService
    {
        private readonly ApplicationDBContext _context;

        public ProductServices(ApplicationDBContext context)
        {
            _context = context;
        }

        public async Task<List<Product>> GetProductsByCategoryAsync(int categoryId)
        {
            return await _context.Products
                .Include(p => p.ProductCategories)
                .ThenInclude(pc => pc.Category)
                .Where(p => p.ProductCategories.Any(pc => pc.CategoryID == categoryId))
                .ToListAsync();
        }

        public async Task<bool> AdjustPriceAsync(int productId, decimal percentage, decimal fixedAmount)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null) throw new Exception("Product not found.");

            var adjustedPrice = product.Price * (1 + (percentage / 100)) + fixedAmount;
            if (adjustedPrice < 0) throw new Exception("Price adjustment results in a negative price.");

            product.Price = adjustedPrice;

            _context.Products.Update(product);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> AdjustPricesBulkAsync(List<int> productIds, decimal percentage, decimal fixedAmount)
        {
            var products = await _context.Products
                .Where(p => productIds.Contains(p.ProductID))
                .ToListAsync();

            foreach (var product in products)
            {
                var adjustedPrice = product.Price * (1 + (percentage / 100)) + fixedAmount;
                if (adjustedPrice < 0) throw new Exception($"Negative price for product {product.Name}.");

                product.Price = adjustedPrice;
            }

            _context.Products.UpdateRange(products);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> IsSkuUniqueAsync(string sku, int? productId = null)
        {
            return !await _context.Products
                .AnyAsync(p => p.SKU == sku && (!productId.HasValue || p.ProductID != productId));
        }

        public async Task<Product> CreateProductAsync(Product product)
        {
            if (!await IsSkuUniqueAsync(product.SKU))
                throw new Exception("SKU must be unique.");

            _context.Products.Add(product);
            await _context.SaveChangesAsync();
            return product;
        }

        public async Task<Product> UpdateProductAsync(int productId, Product product)
        {
            var existingProduct = await _context.Products.FindAsync(productId);
            if (existingProduct == null) throw new Exception("Product not found.");

            if (!await IsSkuUniqueAsync(product.SKU, productId))
                throw new Exception("SKU must be unique.");

            existingProduct.Name = product.Name;
            existingProduct.Description = product.Description;
            existingProduct.Price = product.Price;
            existingProduct.SKU = product.SKU;

            _context.Products.Update(existingProduct);
            await _context.SaveChangesAsync();
            return existingProduct;
        }
    }

}
